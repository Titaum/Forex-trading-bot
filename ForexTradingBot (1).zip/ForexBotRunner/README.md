# 🤖 Professional Forex Trading Bot

A fully automated Forex trading bot built with Node.js that uses multi-indicator confluence strategy to generate trade signals and execute trades with proper risk management.

## ✨ Features

### Trading Strategy
- **Multi-Indicator Confluence**: Combines 4 technical indicators (RSI, MACD, Bollinger Bands, EMA) to generate high-confidence signals
- **Only trades when 3+ indicators agree**, reducing false signals
- **Supports multiple currency pairs**: EUR/USD, GBP/USD, USD/JPY, and more

### Risk Management
- **Automatic Position Sizing**: Calculates lot size based on account balance and risk percentage
- **Stop Loss & Take Profit**: Predefined exit levels for every trade
- **Daily Loss Limit**: Stops trading if daily loss exceeds threshold
- **Max Open Trades**: Limits concurrent positions to avoid over-exposure

### Indicators
- **RSI (Relative Strength Index)**: Detects overbought/oversold conditions
- **MACD (Moving Average Convergence Divergence)**: Identifies trend changes
- **Bollinger Bands**: Recognizes mean reversion opportunities
- **EMA (Exponential Moving Average)**: Confirms trend direction

### Monitoring & Logging
- **Real-time Status**: Displays balance, P&L, open trades, and win rate
- **Trade History**: Saves all trades with entry/exit prices and P&L
- **Performance Metrics**: Tracks daily P&L, win rate, and account growth

## 🚀 Quick Start

### 1. Installation
```bash
cd /home/ubuntu/ForexBotRunner
npm install
```

### 2. Run the Bot
```bash
npm start
```

The bot will start trading immediately and display real-time status updates every 60 seconds.

### 3. Monitor the Bot
The console will show:
- ✅ Trades opened with entry price and risk levels
- 🔴 Trades closed with profit/loss
- 📊 Status updates with balance, P&L, and win rate
- 📍 Open trades with current pips

### 4. Stop the Bot
Press `Ctrl+C` to stop. The bot will save all trade history to a JSON file.

## ⚙️ Configuration

Edit the `CONFIG` object in `bot.js` to customize:

```javascript
const CONFIG = {
  // Trading Pairs
  tradingPairs: ['EUR/USD', 'GBP/USD', 'USD/JPY'],
  
  // Strategy Settings
  rsiPeriod: 14,              // RSI calculation period
  rsiOverbought: 70,          // RSI overbought threshold
  rsiOversold: 30,            // RSI oversold threshold
  macdFastPeriod: 12,         // MACD fast EMA
  macdSlowPeriod: 26,         // MACD slow EMA
  bollingerPeriod: 20,        // Bollinger Bands period
  emaFastPeriod: 9,           // Fast EMA period
  emaSlowPeriod: 21,          // Slow EMA period
  
  // Risk Management
  riskPercentage: 1.0,        // Risk 1% per trade
  stopLossPips: 30,           // 30 pips stop loss
  takeProfitPips: 60,         // 60 pips take profit
  maxOpenTrades: 5,           // Max 5 open trades
  maxDailyLossPercentage: 5.0,// Stop if lose 5% daily
  
  // Bot Settings
  initialBalance: 10000,      // Starting account balance
  updateInterval: 5000,       // Update every 5 seconds
};
```

## 📊 Example Output

```
🤖 FOREX TRADING BOT - STARTING...

⚙️  Configuration:
   Pairs: EUR/USD, GBP/USD, USD/JPY
   Risk per Trade: 1%
   Stop Loss: 30 pips | Take Profit: 60 pips
   Initial Balance: $10000

✅ Bot is running! Press Ctrl+C to stop.

🟢 TRADE OPENED: EUR/USD BUY @ 1.08523
   Units: 100000 | SL: 1.08223 | TP: 1.08823

🟢 TRADE CLOSED: EUR/USD | P&L: $50.00 (0.50%)

======================================================================
📊 BOT STATUS - Uptime: 0h 5m 23s
======================================================================
💰 Balance: $10050.00 (Started: $10000.00)
📈 Daily P&L: $50.00 (0.50%)
📊 Total Trades: 1 | Open Trades: 0
🎯 Win Rate: 100.0% (1/1)
======================================================================
```

## 📈 Trade History

After stopping the bot, a JSON file is created with all trade details:

```json
{
  "config": { ... },
  "summary": {
    "totalTrades": 10,
    "openTrades": 0,
    "finalBalance": 10250.00,
    "totalPL": 250.00,
    "dailyPL": 250.00
  },
  "trades": [
    {
      "id": "TRADE-1234567890-abc123",
      "pair": "EUR/USD",
      "direction": "BUY",
      "entryPrice": 1.08523,
      "units": 100000,
      "exitPrice": 1.08823,
      "profitLoss": 50.00,
      "profitLossPercent": "0.50",
      "status": "CLOSED",
      "exitReason": "Take Profit Hit",
      "reason": "RSI Oversold (28.5) | MACD Bullish | Price Below Lower Band | EMA Uptrend"
    }
  ]
}
```

## 🔧 Advanced Usage

### Connect to OANDA (Real Trading)
To connect to a real OANDA account:

1. Get your API key from OANDA
2. Modify the `ForexDataGenerator` class to fetch real prices from OANDA API
3. Update the `TradingEngine` to execute real orders via OANDA API

### Backtesting
To backtest the strategy:

1. Load historical price data instead of generating new candles
2. Run the bot against historical data
3. Compare results with different parameters

### Performance Optimization
- Adjust `updateInterval` for faster/slower trading
- Modify indicator periods for different market conditions
- Change risk percentage based on account size

## ⚠️ Disclaimer

This bot is for educational purposes. Trading Forex involves substantial risk of loss. Past performance does not guarantee future results. Always:
- Test on practice accounts first
- Start with small position sizes
- Monitor the bot regularly
- Use proper risk management

## 📝 License

MIT

## 🤝 Support

For issues or questions, check the trade history JSON file for detailed logs of all trades and decisions made by the bot.

---

**Happy Trading! 🚀**
