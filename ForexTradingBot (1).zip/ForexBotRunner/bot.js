#!/usr/bin/env node

/**
 * FOREX TRADING BOT - LIVE RUNNER
 * 
 * This bot:
 * ✅ Generates realistic Forex price data
 * ✅ Calculates technical indicators (RSI, MACD, Bollinger Bands, EMA)
 * ✅ Generates multi-indicator trade signals
 * ✅ Executes trades with proper position sizing
 * ✅ Manages risk with stop loss and take profit
 * ✅ Logs all trades and performance metrics
 * 
 * Usage: node bot.js
 */

const fs = require('fs');
const path = require('path');

// ============ CONFIGURATION ============
const CONFIG = {
  // Trading Pairs
  tradingPairs: ['EUR/USD', 'GBP/USD', 'USD/JPY'],
  
  // Strategy Settings
  rsiPeriod: 14,
  rsiOverbought: 70,
  rsiOversold: 30,
  macdFastPeriod: 12,
  macdSlowPeriod: 26,
  macdSignalPeriod: 9,
  bollingerPeriod: 20,
  bollingerStdDev: 2.0,
  emaFastPeriod: 9,
  emaSlowPeriod: 21,
  
  // Risk Management
  riskPercentage: 1.0,        // Risk 1% per trade
  stopLossPips: 30,           // 30 pips stop loss
  takeProfitPips: 60,         // 60 pips take profit
  maxOpenTrades: 5,           // Max 5 open trades
  maxDailyLossPercentage: 5.0, // Stop trading if lose 5% daily
  
  // Bot Settings
  initialBalance: 10000,      // Start with $10,000
  updateInterval: 5000,       // Update every 5 seconds
  candleInterval: 900000,     // 15-minute candles (900 seconds)
};

// ============ PRICE DATA GENERATOR ============
class ForexDataGenerator {
  constructor(pair) {
    this.pair = pair;
    this.prices = this.initializePrices();
    this.candles = [];
  }

  initializePrices() {
    const ranges = {
      'EUR/USD': { min: 1.0500, max: 1.1200, current: 1.0850 },
      'GBP/USD': { min: 1.2000, max: 1.3500, current: 1.2650 },
      'USD/JPY': { min: 130.0, max: 155.0, current: 145.5 },
    };
    return ranges[this.pair] || { min: 1.0, max: 1.5, current: 1.25 };
  }

  generateCandle() {
    const range = this.prices;
    const midPrice = (range.min + range.max) / 2;
    const deviation = range.current - midPrice;
    const meanReversionForce = -deviation * 0.001;
    const randomChange = (Math.random() - 0.5) * 0.002;
    const change = randomChange + meanReversionForce;

    const open = range.current;
    const close = range.current + change;
    const high = Math.max(open, close) + Math.abs(Math.random() * 0.002);
    const low = Math.min(open, close) - Math.abs(Math.random() * 0.002);

    const candle = {
      timestamp: new Date(),
      open,
      high,
      low,
      close,
      volume: Math.floor(Math.random() * 1000000 + 500000),
    };

    range.current = close;
    this.candles.push(candle);
    if (this.candles.length > 200) this.candles.shift();

    return candle;
  }
}

// ============ TECHNICAL INDICATORS ============
class Indicators {
  static calculateRSI(closes, period = 14) {
    if (closes.length < period + 1) return 50;

    let gains = 0, losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const change = closes[i] - closes[i - 1];
      if (change > 0) gains += change;
      else losses -= change;
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;
    const rs = avgGain / (avgLoss || 1);
    return 100 - (100 / (1 + rs));
  }

  static calculateEMA(values, period) {
    if (values.length < period) return values[values.length - 1];
    const k = 2 / (period + 1);
    let ema = values.slice(0, period).reduce((a, b) => a + b) / period;
    for (let i = period; i < values.length; i++) {
      ema = values[i] * k + ema * (1 - k);
    }
    return ema;
  }

  static calculateSMA(values, period) {
    if (values.length < period) return values[values.length - 1];
    const sum = values.slice(-period).reduce((a, b) => a + b);
    return sum / period;
  }

  static calculateBollingerBands(closes, period = 20, stdDev = 2) {
    const middle = this.calculateSMA(closes, period);
    const variance = closes.slice(-period).reduce((sum, val) => sum + Math.pow(val - middle, 2), 0) / period;
    const std = Math.sqrt(variance);
    return {
      upper: middle + std * stdDev,
      middle,
      lower: middle - std * stdDev,
    };
  }

  static calculateMACD(closes, fast = 12, slow = 26, signal = 9) {
    const ema12 = this.calculateEMA(closes, fast);
    const ema26 = this.calculateEMA(closes, slow);
    const macdLine = ema12 - ema26;
    return { line: macdLine, signal: macdLine * 0.95 };
  }

  static analyze(candles, config) {
    if (candles.length < 50) return null;

    const closes = candles.map(c => c.close);
    const rsi = this.calculateRSI(closes, config.rsiPeriod);
    const macd = this.calculateMACD(closes, config.macdFastPeriod, config.macdSlowPeriod);
    const bb = this.calculateBollingerBands(closes, config.bollingerPeriod, config.bollingerStdDev);
    const emaFast = this.calculateEMA(closes, config.emaFastPeriod);
    const emaSlow = this.calculateEMA(closes, config.emaSlowPeriod);
    const currentPrice = closes[closes.length - 1];

    return { rsi, macd, bb, emaFast, emaSlow, currentPrice };
  }
}

// ============ TRADE SIGNAL GENERATOR ============
class SignalGenerator {
  static generate(pair, indicators, config) {
    if (!indicators) return null;

    let buySignals = 0, sellSignals = 0;
    const reasons = {};

    // RSI Signal
    if (indicators.rsi < config.rsiOversold) {
      buySignals++;
      reasons.rsi = `RSI Oversold (${indicators.rsi.toFixed(2)})`;
    } else if (indicators.rsi > config.rsiOverbought) {
      sellSignals++;
      reasons.rsi = `RSI Overbought (${indicators.rsi.toFixed(2)})`;
    }

    // MACD Signal
    if (indicators.macd.line > indicators.macd.signal) {
      buySignals++;
      reasons.macd = 'MACD Bullish';
    } else {
      sellSignals++;
      reasons.macd = 'MACD Bearish';
    }

    // Bollinger Bands Signal
    if (indicators.currentPrice < indicators.bb.lower) {
      buySignals++;
      reasons.bb = 'Price Below Lower Band';
    } else if (indicators.currentPrice > indicators.bb.upper) {
      sellSignals++;
      reasons.bb = 'Price Above Upper Band';
    }

    // EMA Signal
    if (indicators.emaFast > indicators.emaSlow) {
      buySignals++;
      reasons.ema = 'EMA Uptrend';
    } else {
      sellSignals++;
      reasons.ema = 'EMA Downtrend';
    }

    const confidence = Math.max(buySignals, sellSignals);
    if (confidence >= 3) {
      return {
        pair,
        direction: buySignals > sellSignals ? 'BUY' : 'SELL',
        confidence,
        reason: Object.values(reasons).join(' | '),
        price: indicators.currentPrice,
      };
    }

    return null;
  }
}

// ============ TRADING ENGINE ============
class TradingEngine {
  constructor(config) {
    this.config = config;
    this.balance = config.initialBalance;
    this.trades = [];
    this.openTrades = [];
    this.dailyPL = 0;
    this.dailyStartBalance = config.initialBalance;
    this.generators = {};
    this.startTime = new Date();

    config.tradingPairs.forEach(pair => {
      this.generators[pair] = new ForexDataGenerator(pair);
    });
  }

  canOpenTrade() {
    const dailyLossPercent = ((this.dailyStartBalance - this.balance) / this.dailyStartBalance) * 100;
    return (
      this.openTrades.length < this.config.maxOpenTrades &&
      dailyLossPercent < this.config.maxDailyLossPercentage
    );
  }

  calculatePositionSize(stopLossPips, entryPrice) {
    const riskAmount = (this.balance * (this.config.riskPercentage / 100));
    const pipValue = stopLossPips / 10000;
    return Math.floor((riskAmount / pipValue) / 100000) * 100000;
  }

  executeTrade(signal) {
    if (!this.canOpenTrade()) return;

    const units = this.calculatePositionSize(this.config.stopLossPips, signal.price);
    if (units === 0) return;

    const trade = {
      id: `TRADE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      pair: signal.pair,
      direction: signal.direction,
      entryPrice: signal.price,
      units,
      stopLoss: signal.direction === 'BUY' 
        ? signal.price - (this.config.stopLossPips / 10000)
        : signal.price + (this.config.stopLossPips / 10000),
      takeProfit: signal.direction === 'BUY'
        ? signal.price + (this.config.takeProfitPips / 10000)
        : signal.price - (this.config.takeProfitPips / 10000),
      openedAt: new Date(),
      reason: signal.reason,
    };

    this.openTrades.push(trade);
    console.log(`\n🟢 TRADE OPENED: ${trade.pair} ${trade.direction} @ ${trade.entryPrice.toFixed(5)}`);
    console.log(`   Units: ${trade.units} | SL: ${trade.stopLoss.toFixed(5)} | TP: ${trade.takeProfit.toFixed(5)}`);
  }

  checkTradeExit(trade, currentPrice) {
    let exitPrice = null;
    let reason = '';

    if (trade.direction === 'BUY') {
      if (currentPrice >= trade.takeProfit) {
        exitPrice = trade.takeProfit;
        reason = 'Take Profit Hit';
      } else if (currentPrice <= trade.stopLoss) {
        exitPrice = trade.stopLoss;
        reason = 'Stop Loss Hit';
      }
    } else {
      if (currentPrice <= trade.takeProfit) {
        exitPrice = trade.takeProfit;
        reason = 'Take Profit Hit';
      } else if (currentPrice >= trade.stopLoss) {
        exitPrice = trade.stopLoss;
        reason = 'Stop Loss Hit';
      }
    }

    if (exitPrice) {
      const pips = (exitPrice - trade.entryPrice) * 10000;
      const profitLoss = (pips / 10) * (trade.units / 100000);

      const closedTrade = {
        ...trade,
        exitPrice,
        closedAt: new Date(),
        profitLoss,
        profitLossPercent: ((profitLoss / (this.balance - profitLoss)) * 100).toFixed(2),
        status: 'CLOSED',
        exitReason: reason,
      };

      this.trades.push(closedTrade);
      this.balance += profitLoss;
      this.dailyPL += profitLoss;

      const emoji = profitLoss >= 0 ? '🟢' : '🔴';
      console.log(`\n${emoji} TRADE CLOSED: ${closedTrade.pair} | P&L: $${profitLoss.toFixed(2)} (${closedTrade.profitLossPercent}%)`);

      return true;
    }

    return false;
  }

  updateTrades(generators) {
    const closedTradeIds = new Set();

    this.openTrades.forEach(trade => {
      const currentPrice = generators[trade.pair].prices.current;
      if (this.checkTradeExit(trade, currentPrice)) {
        closedTradeIds.add(trade.id);
      }
    });

    this.openTrades = this.openTrades.filter(t => !closedTradeIds.has(t.id));
  }

  tick(generators) {
    // Update all pairs
    Object.keys(generators).forEach(pair => {
      generators[pair].generateCandle();
    });

    // Check for trade exits
    this.updateTrades(generators);

    // Generate signals and open new trades
    Object.keys(generators).forEach(pair => {
      const indicators = Indicators.analyze(generators[pair].candles, this.config);
      const signal = SignalGenerator.generate(pair, indicators, this.config);
      if (signal) {
        this.executeTrade(signal);
      }
    });
  }

  printStatus() {
    const uptime = Math.floor((new Date() - this.startTime) / 1000);
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = uptime % 60;

    console.log('\n' + '='.repeat(70));
    console.log(`📊 BOT STATUS - Uptime: ${hours}h ${minutes}m ${seconds}s`);
    console.log('='.repeat(70));
    console.log(`💰 Balance: $${this.balance.toFixed(2)} (Started: $${this.config.initialBalance.toFixed(2)})`);
    console.log(`📈 Daily P&L: $${this.dailyPL.toFixed(2)} (${((this.dailyPL / this.config.initialBalance) * 100).toFixed(2)}%)`);
    console.log(`📊 Total Trades: ${this.trades.length} | Open Trades: ${this.openTrades.length}`);
    
    if (this.trades.length > 0) {
      const winners = this.trades.filter(t => t.profitLoss > 0).length;
      const winRate = ((winners / this.trades.length) * 100).toFixed(1);
      console.log(`🎯 Win Rate: ${winRate}% (${winners}/${this.trades.length})`);
    }

    if (this.openTrades.length > 0) {
      console.log(`\n📍 Open Trades:`);
      this.openTrades.forEach(trade => {
        const currentPrice = this.generators[trade.pair].prices.current;
        const pips = (currentPrice - trade.entryPrice) * 10000;
        const emoji = pips > 0 ? '📈' : '📉';
        console.log(`   ${emoji} ${trade.pair} ${trade.direction} @ ${trade.entryPrice.toFixed(5)} (${pips.toFixed(1)} pips)`);
      });
    }
    console.log('='.repeat(70));
  }
}

// ============ MAIN BOT RUNNER ============
async function main() {
  console.log('\n🤖 FOREX TRADING BOT - STARTING...\n');
  console.log('⚙️  Configuration:');
  console.log(`   Pairs: ${CONFIG.tradingPairs.join(', ')}`);
  console.log(`   Risk per Trade: ${CONFIG.riskPercentage}%`);
  console.log(`   Stop Loss: ${CONFIG.stopLossPips} pips | Take Profit: ${CONFIG.takeProfitPips} pips`);
  console.log(`   Initial Balance: $${CONFIG.initialBalance}\n`);

  const engine = new TradingEngine(CONFIG);

  let tickCount = 0;
  const interval = setInterval(() => {
    tickCount++;
    engine.tick(engine.generators);

    if (tickCount % 12 === 0) {
      engine.printStatus();
    }
  }, CONFIG.updateInterval);

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n\n🛑 Shutting down bot...');
    clearInterval(interval);
    engine.printStatus();
    
    // Save trade history
    const logFile = path.join(__dirname, `trades-${Date.now()}.json`);
    fs.writeFileSync(logFile, JSON.stringify({
      config: CONFIG,
      summary: {
        totalTrades: engine.trades.length,
        openTrades: engine.openTrades.length,
        finalBalance: engine.balance,
        totalPL: engine.balance - CONFIG.initialBalance,
        dailyPL: engine.dailyPL,
      },
      trades: engine.trades,
      openTrades: engine.openTrades,
    }, null, 2));

    console.log(`\n✅ Trade history saved to: ${logFile}`);
    process.exit(0);
  });

  console.log('✅ Bot is running! Press Ctrl+C to stop.\n');
}

main().catch(console.error);
